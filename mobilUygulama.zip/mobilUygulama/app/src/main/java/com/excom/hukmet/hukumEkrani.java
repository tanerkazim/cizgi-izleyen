package com.excom.hukmet;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;

import java.io.IOException;
import java.util.UUID;


public class hukumEkrani extends ActionBarActivity {

   // Button btnOn, btnOff, btnDis;
    ImageButton Up, Down, Right, Left, Disconnect, Run;
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(Cihazlar.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the hukumEkrani
        setContentView(R.layout.hukum_paneli);

        //call the widgets
        Up = (ImageButton)findViewById(R.id.up_btn);
        Down = (ImageButton)findViewById(R.id.down_btn);
        Right = (ImageButton)findViewById(R.id.right_btn);
        Left = (ImageButton)findViewById(R.id.left_btn);
        Run = (ImageButton)findViewById(R.id.run_btn);
        Disconnect = (ImageButton)findViewById(R.id.dis_btn);

        new ConnectBT().execute(); //Call the class to connect

        //commands to be sent to bluetooth
        Up.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                ileri();      //method to turn on
            }
        });

        Down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                geri();   //method to turn off
            }
        });

        Right.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                sag();      //method to turn on
            }
        });

        Left.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                sol();      //method to turn on
            }
        });

        Run.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                basla();      //method to turn on
            }
        });

        Disconnect.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Disconnect(); //close connection
            }
        });


    }

    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
            }
            catch (IOException e)
            { msg("Hata");}
        }
        finish(); //return to the first layout

    }

    private void geri()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("d".getBytes());
            }
            catch (IOException e)
            {
                msg("Hata");
            }
        }
    }

    private void ileri()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("u".getBytes());
            }
            catch (IOException e)
            {
                msg("Hata");
            }
        }
    }

    private void sag()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("r".getBytes());
            }
            catch (IOException e)
            {
                msg("Hata");
            }
        }
    }

    private void sol()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("l".getBytes());
            }
            catch (IOException e)
            {
                msg("Hata");
            }
        }
    }

    private void basla()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("s".getBytes());
            }
            catch (IOException e)
            {
                msg("Hata");
            }
        }
    }

    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_hukum_paneli, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(hukumEkrani.this, "Bağlanıyor..", "Hükmetmeye Hazır Ol!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                 myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                 BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                 btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                 BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                 btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Bağlantı başarısız. Tekrar deneyin.");
                finish();
            }
            else
            {
                msg("DİNLEMEYE HAZIR!");
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }
}
